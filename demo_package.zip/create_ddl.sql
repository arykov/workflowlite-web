create table ProcessInfo (
    process_id              numeric(20) primary key,
    process_type            varchar(255),
    parent_callback_info    varchar(255),
    serializable_data       clob,
    net_state               varchar(255),
    status                  varchar(255),
    created_timestamp       timestamp,
    completed_timestamp     timestamp
);

create table ProcessMessage (
    message_id              numeric(20) primary key,
    uuid					varchar(36) unique,
    process_id              numeric(20) references ProcessInfo(process_id),
    status                  varchar(255),
    delivery_attempts       numeric(20),
    control_name            varchar(255),
    event_type              varchar(255),
    resume_data             clob
);

create table ProcessLogEntry (
    entry_id                numeric(20) primary key,
    process_id              numeric(20) references ProcessInfo(process_id),
    message_id              numeric(20) references ProcessMessage(message_id),
    created_timestamp       timestamp,
    event                   varchar(255),
    elapsed_millis          numeric(20),
    stack_trace             clob
);

create table CORRELATION(
   CHANNEL VARCHAR(100) ,
   CORRELATION_ID VARCHAR(100) ,  
   BEAN_ID VARCHAR(100), 
   PROCESS_ID numeric(20), 
   CONTROL_NAME VARCHAR(100),  
   EVENT_ID VARCHAR(100) 
);

create sequence wfl_orm_seq start with 1;

